#include <pwd.h>
#include <stdlib.h>
#include <unistd.h>

#ifndef NAME
#  error "We need a NAME to set as the user!"
#endif

#define xstr(s) str(s)
#define str(x) #x

int
main(int argc, char **argv)
{
  struct passwd passwdEntry;
  struct passwd *passwdEntryResult;
  long passwdBufferLength = sysconf(_SC_GETPW_R_SIZE_MAX);
  char *passwdBuffer = (char*) malloc(sizeof(char) * passwdBufferLength);

  if(getpwnam_r(xstr(NAME), &passwdEntry, passwdBuffer, passwdBufferLength, &passwdEntryResult) != 0
      && &passwdEntry != passwdEntryResult)
    { perror("getpwnam_r(3)"); return 1; }

  // set the real, effective and saved uid and gid
  // this will be the id's of the flagXX users
  if(setresuid(passwdEntry.pw_uid, passwdEntry.pw_uid, passwdEntry.pw_uid) != 0)
    { perror("setresuid(3)"); return 1; }
#if 0
  if(setresgid(passwdEntry.pw_gid, passwdEntry.pw_gid, passwdEntry.pw_gid) != 0)
    { perror("setresgid(3)"); return 2; }
#endif

  // we definately don't need this anymore
  free(passwdBuffer);

  // do we wish to delete this application?
  if(argc == 2 && strncmp("delete", argv[1], 7) == 0) {
    if(unlink(argv[0]) != 0) // then delete it
      { perror("unlink(3)"); return 2; }
    return 0;
  }

  // run bash as uid:gid user
  system("/bin/bash");

  return 0;
}
